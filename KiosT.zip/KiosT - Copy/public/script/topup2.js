document.addEventListener("DOMContentLoaded", function () {
  const cardChoices = document.querySelectorAll(".card-choice");
  const paymentMethods = document.querySelectorAll(".payment-method");
  const priceTotal = document.querySelector(".price-total");
  const discountInput = document.querySelector("#discount");
  const discountButton = document.querySelector(".btn-use");
  const buyNowButton = document.querySelector(".buy-now");

  let selectedPrice = 0;
  let discountApplied = false;
  let selectedPaymentMethod = "";

  cardChoices.forEach((card) => {
    card.addEventListener("click", function () {
      cardChoices.forEach((c) => c.classList.remove("selected"));
      card.classList.add("selected");
      selectedPrice = parseInt(card.getAttribute("data-price"));
      updateTotalPrice();
    });
  });

  paymentMethods.forEach((method) => {
    method.addEventListener("click", function () {
      paymentMethods.forEach((m) => m.classList.remove("selected"));
      method.classList.add("selected");
      selectedPaymentMethod = method.querySelector("img").src;
    });
  });

  discountButton.addEventListener("click", function () {
    const promoCode = discountInput.value.trim().toLowerCase();
    if (promoCode === "kiost") {
      discountApplied = true;
    } else {
      discountApplied = false;
      alert("Kode promo tidak valid!");
    }
    updateTotalPrice();
  });

  function updateTotalPrice() {
    let totalPrice = selectedPrice;
    if (discountApplied) {
      totalPrice *= 0.8; // Apply 20% discount
    }
    priceTotal.textContent = `Rp. ${totalPrice.toLocaleString("id-ID")}`;
  }

  // Modal Logic
  const modal = document.getElementById("confirmationModal");
  const span = document.getElementsByClassName("close-button")[0];
  const processPaymentButton = document.getElementById("processPayment");

  buyNowButton.addEventListener("click", function () {
    const userId = document.querySelector(".input-id").value;
    const randomName = `User${Math.floor(Math.random() * 10000)}`;
    const selectedCard = document.querySelector(".card-choice.selected");
    let category = "Gems";
    let quantity = "";

    if (selectedCard) {
      quantity = selectedCard.querySelector("p").textContent.trim();
    }

    const totalPrice = priceTotal.textContent;

    document.getElementById("confirmId").textContent = userId;
    document.getElementById("confirmName").textContent = randomName;
    document.getElementById("confirmCategory").textContent = category;
    document.getElementById("confirmPrice").textContent = totalPrice;
    document.getElementById("confirmPaymentMethod").src = selectedPaymentMethod;

    modal.style.display = "block";
  });

  span.onclick = function () {
    modal.style.display = "none";
  };

  window.onclick = function (event) {
    if (event.target == modal) {
      modal.style.display = "none";
    }
  };

  processPaymentButton.addEventListener("click", function () {
    const priceTotal = document.querySelector(".price-total");
    const randomName = `INV${Math.floor(Math.random() * 10000)}`;
    const selectedCard = document.querySelector(".card-choice.selected");
    let quantity = "";

    if (selectedCard) {
      quantity = selectedCard.querySelector("p").textContent.trim();
    }

    const data = {
      date: new Date().toLocaleDateString("id-ID"),
      name: "Clash Of Clans",
      category: "gems",
      quantity: quantity,
      price: priceTotal.textContent,
      invoice: randomName,
    };

    // Simpan data ke file JSON
    saveDataToJSON(data);

    modal.style.display = "none";
  });

  function saveDataToJSON(data) {
    const url = "https://kiost.vercel.app/save-data"; // Sesuaikan dengan URL endpoint di server Anda

    fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to save data");
        }
        alert("Pembayaran Berhasil!");
        modal.style.display = "none";
      })
      .catch((error) => {
        console.error("Error saving data:", error);
        alert("Gagal melakukan pembayaran. Silakan coba lagi.");
      });
  }
});
